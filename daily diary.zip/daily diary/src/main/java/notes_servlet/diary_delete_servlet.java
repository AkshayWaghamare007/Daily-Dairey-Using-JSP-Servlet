package notes_servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notes_DB.DB;
import notes_Dao.diary_write_Dao;


@WebServlet("/diary_delete")
public class diary_delete_servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
try {
			
			int id=Integer.parseInt(req.getParameter("id"));
			diary_write_Dao dao=new diary_write_Dao(DB.getConn());
			boolean f=dao.deletePrivcy(id);
			HttpSession session = req.getSession();
			if(f)
			{
				 session=req.getSession();
				session.setAttribute("reg-sucess1","Registation Sucessfully");
				resp.sendRedirect("view_diary.jsp");
			}
			else
			{
				session=req.getSession();
				session.setAttribute("failed-msg1","Somethink went wrong");
				resp.sendRedirect("view_diary.jsp");
			}
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}
