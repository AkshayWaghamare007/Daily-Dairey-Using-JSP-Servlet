package notes_servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notes_DB.DB;
import notes_Dao.diary_write_Dao;
import notes_moels.dairey_write_moel;


@WebServlet("/diary_update_servlet")
public class diary_update_servlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		

		try {
			int id=Integer.parseInt(req.getParameter("id"));
			String title = req.getParameter("title");
			String date = req.getParameter("date");
			String discription = req.getParameter("discription");
			
			dairey_write_moel j=new dairey_write_moel();
			j.setId(id);
			j.setTitle(title);
			j.setDate(date);
			j.setMessage(discription);
			
			diary_write_Dao ps=new diary_write_Dao(DB.getConn());
			boolean f= ps.updatePrivcy(j);
			
			
			HttpSession session;
			if(f)
			{
				 session=req.getSession();
				session.setAttribute("reg-sucess1","Registation Sucessfully");
				resp.sendRedirect("view_diary.jsp");
			}
			else
			{
				session=req.getSession();
				session.setAttribute("failed-msg1","Somethink went wrong");
				resp.sendRedirect("view_diary.jsp");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
