package notes_servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notes_DB.DB;

import notes_Dao.Register_Dao;
import notes_moels.register_model;




@WebServlet("/login_servlet")
public class login_servlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		String email=req.getParameter("email");
		String pass=req.getParameter("pass");
		
		System.out.println(email+pass);
		register_model us=new register_model();
		us.setEmail(email);
		us.setPass(pass);
		
		Register_Dao dao=new Register_Dao(DB.getConn());
		register_model user=dao.LoginUser(us);
		
		if(user!=null)
		{
			HttpSession session=req.getSession();
			session.setAttribute("userD", user);
			response.sendRedirect("index.jsp");
		}
		else
		{
			HttpSession session=req.getSession();
			session.setAttribute("login-failed", "invalide username or password");
			response.sendRedirect("login.jsp");
		}
	
}
}