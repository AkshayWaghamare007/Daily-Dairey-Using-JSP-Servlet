package notes_servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notes_DB.DB;

import notes_Dao.Register_Dao;
import notes_moels.register_model;


@WebServlet("/register_servlet")
public class register_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public register_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String email = request.getParameter("email");
		
		String name = request.getParameter("name");
		String email  = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String  address= request.getParameter("address");
		String pass = request.getParameter("pass");
		
		System.out.println(name+email+mobile+address+pass);
		
		register_model us=new register_model();
		us.setName(name);
		us.setEmail(email);
		us.setMobile(mobile);
		us.setAddres(address);
		us.setPass(pass);
		
		Register_Dao p=new Register_Dao(DB.getConn());
		boolean f= p.addRegisterUser(us);
		
		PrintWriter out=response.getWriter();
		HttpSession session;
		if(f)
		{
			 session=request.getSession();
			session.setAttribute("reg-sucess1","Registation Sucessfully");
			response.sendRedirect("login.jsp");
		}
		else
		{
			session=request.getSession();
			session.setAttribute("failed-msg1","Somethink went wrong");
			response.sendRedirect("register.jsp");
		}
		
		
		
		
	}

}
