package notes_servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notes_DB.DB;

import notes_Dao.diary_write_Dao;
import notes_moels.dairey_write_moel;

@WebServlet("/write_diary_servlet")
public class write_diary_servlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		String title = req.getParameter("title");
		String date  = req.getParameter("date");
		String message = req.getParameter("message");
		String uid = req.getParameter("uid");
		
		System.out.println(title+date+message+uid);
		dairey_write_moel us=new dairey_write_moel();
		us.setTitle(title);
		us.setDate(date);
		us.setMessage(message);
		us.setUid(uid);
		
		diary_write_Dao p=new diary_write_Dao(DB.getConn());
		boolean f= p.addDiary(us);
		
		PrintWriter out=resp.getWriter();
		HttpSession session;
		if(f)
		{
			 session=req.getSession();
			session.setAttribute("reg-sucess1","Registation Sucessfully");
			resp.sendRedirect("write_diary.jsp");
		}
		else
		{
			session=req.getSession();
			session.setAttribute("failed-msg1","Somethink went wrong");
			resp.sendRedirect("index.jsp");
		}
		
		
	}

	
	
}
