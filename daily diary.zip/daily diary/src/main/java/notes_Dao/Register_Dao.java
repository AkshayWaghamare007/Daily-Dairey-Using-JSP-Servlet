package notes_Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import notes_moels.register_model;


public class Register_Dao {
private Connection conn;
	
	
	public Register_Dao(Connection conn) {
	super();
	this.conn=conn;
}


	public boolean addRegisterUser(register_model us)
	{
		boolean f=false;
		
		try {
			String qurty="insert into register(name,email,mobile,address,pass) values (?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(qurty);
		
			ps.setString(1,us.getName());
			ps.setString(2, us.getEmail());
			ps.setString(3,us.getMobile());
			ps.setString(4,us.getAddres());
			ps.setString(5,us.getPass());
		int i=	ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	
	public register_model LoginUser(register_model us)
	{
		register_model user=null;
		try {
			
			
			String query="select *from register where email=? and pass=?";
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, us.getEmail());
			ps.setString(2, us.getPass());
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				user=new register_model();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setMobile(rs.getString("mobile"));
				user.setAddres(rs.getNString("address"));
				user.setPass(rs.getString("pass"));
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		
		return user;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}