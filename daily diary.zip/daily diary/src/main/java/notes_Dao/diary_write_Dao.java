package notes_Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import notes_moels.dairey_write_moel;
import java.beans.JavaBean;

public class diary_write_Dao {
private Connection conn;
	public diary_write_Dao(Connection conn) {
	super();
	this.conn = conn;
}



	public boolean addDiary(dairey_write_moel us)
	{
		boolean f=false;
		
		try {
			String qurty="insert into diary(title,date,message,uid) values (?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(qurty);
			
			ps.setString(1, us.getTitle());
			ps.setString(2, us.getDate());
			ps.setString(3, us.getMessage());
			ps.setString(4, us.getUid());
			
		int i=	ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	
	
	public List<dairey_write_moel> getData(int id)
	{
		List<dairey_write_moel> list=new ArrayList<dairey_write_moel>();
		dairey_write_moel j=null;
		
		
		try {
			
			
			String qu="select * from diary where uid=?";
			
			PreparedStatement ps=conn.prepareStatement(qu);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				j=new dairey_write_moel();
				j.setId(rs.getInt(1));
				j.setTitle(rs.getString(2));
				j.setDate(rs.getDate(3)+"");
				j.setMessage(rs.getString(4));
				list.add(j);
			}
		} catch (Exception e) {
			
		}
		return list;
	}
	
	
	public dairey_write_moel getedit(int id)
	{
		
		dairey_write_moel j=null;
		
		
		try {
			
			
			String qu="select * from diary where id=?";
			PreparedStatement ps=conn.prepareStatement(qu);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				j=new dairey_write_moel();
				j.setId(rs.getInt(1));
				j.setTitle(rs.getString(2));
				j.setDate(rs.getDate(3)+"");
				j.setMessage(rs.getString(4));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return j;
	}
	
	
	
	public boolean updatePrivcy (dairey_write_moel j)
	{
boolean f=false;
		
		try {
			String qurty="update  diary set title=?,date=?,message=? where id=?";
			PreparedStatement ps = conn.prepareStatement(qurty);
			ps.setInt(1, j.getId());
			ps.setString(2, j.getTitle());
			ps.setString(3, j.getDate());
			ps.setString(4, j.getMessage());
			
			
		int i=	ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	
	public boolean deletePrivcy(int id)
	{
		boolean f=false;
		try {
			
			String sql="delete from diary where  id=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			int i=ps.executeUpdate();
			if(i==1)
			{
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	
	
	
	
	
	
	
	
	
}
