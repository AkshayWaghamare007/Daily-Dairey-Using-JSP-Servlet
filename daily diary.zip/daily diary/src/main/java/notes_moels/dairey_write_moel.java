package notes_moels;

public class dairey_write_moel {

	private int id;
	private String title;
	private String date;
	private String message;
	private String uid;
	public dairey_write_moel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public dairey_write_moel(int id, String title, String date, String message, String uid) {
		super();
		this.id = id;
		this.title = title;
		this.date = date;
		this.message = message;
		this.uid = uid;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	
	
}
